# DoodleRepost Android Native MVP

Kotlin Android project using AndroidX Media3 ExoPlayer and Transformer.

## Build the APK using an Android phone only (GitHub Actions)

No PC is required, but you need a GitHub account and an internet connection.

1. Open https://github.com in Chrome and sign in.
2. Create a new **public or private repository** named `DoodleRepost` (do not initialize it with a README).
3. Extract this ZIP using your phone's Files app / file manager.
4. In the repository on GitHub, choose **Add file > Upload files**.
5. Upload the *contents* of the extracted `DoodleRepostAndroid` folder, including the hidden `.github` folder and its `workflows/build-apk.yml` file. If the phone file picker hides dot-folders, enable “show hidden files” or upload the workflow file separately by creating `.github/workflows/build-apk.yml` in GitHub's web editor.
6. Commit the uploaded files to the `main` branch.
7. Open the repository's **Actions** tab. The workflow **Build DoodleRepost APK** should start automatically. If not, open it and choose **Run workflow**.
8. Wait for the run to finish successfully. Open the completed run, scroll to **Artifacts**, and download `DoodleRepost-debug-apk`.
9. Extract the artifact ZIP on the phone. Tap `app-debug.apk` to install. Android may ask you to allow installation from that browser/file manager.

## Build locally in Android Studio

Open this project in Android Studio with JDK 17, Android SDK 35, and Gradle 8.9, then run `assembleDebug`.

## MVP scope and limitations

- Native video picker and ExoPlayer preview.
- Six doodle overlay styles and four color choices.
- Media3 Transformer MP4/H.264 + AAC export attempt.
- Save output to Movies/DoodleRepost.
- The current overlay is a static graphic across the clip; object tracking and time-varying animated doodles are not implemented yet.
- Hardware codec availability and export compatibility vary by Android device. Test with a short clip first.
- Use videos you own or have permission to edit and repost.

This repository contains source code and a cloud-build workflow, **not a precompiled APK**. GitHub Actions builds the APK after the project is uploaded to a repository.
