package com.clipvault.doodlerepost

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.Composition
import androidx.media3.ui.PlayerView
import androidx.media3.exoplayer.ExoPlayer
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import java.io.File
import java.io.FileInputStream

class MainActivity : AppCompatActivity() {
    private var selectedUri: Uri? = null
    private var player: ExoPlayer? = null
    private var transformer: Transformer? = null
    private lateinit var playerView: PlayerView
    private lateinit var fileName: TextView
    private lateinit var statusText: TextView
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar
    private var isExporting = false

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            fileName.text = uri.lastPathSegment ?: "Video dipilih"
            player?.setMediaItem(MediaItem.fromUri(uri))
            player?.prepare()
            player?.playWhenReady = false
            exportButton.isEnabled = true
            statusText.text = "Video siap. Putar preview untuk memeriksa gambar dan suara."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        fileName = findViewById(R.id.fileName)
        statusText = findViewById(R.id.statusText)
        exportButton = findViewById(R.id.exportButton)
        progress = findViewById(R.id.progress)

        player = ExoPlayer.Builder(this).build().also { playerView.player = it }

        setupSpinner(R.id.styleSpinner, listOf("Viral mix", "Scribble", "Panah", "Lingkaran", "Bintang", "Minimal"))
        setupSpinner(R.id.colorSpinner, listOf("Putih", "Kuning", "Biru", "Pink"))
        setupSpinner(R.id.resolutionSpinner, listOf("720p (disarankan)", "1080p"))

        findViewById<Button>(R.id.chooseButton).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        exportButton.setOnClickListener { startExport() }
    }

    private fun setupSpinner(id: Int, values: List<String>) {
        val spinner = findViewById<Spinner>(id)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
    }

    private fun makeDoodleBitmap(width: Int, height: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val colorName = findViewById<Spinner>(R.id.colorSpinner).selectedItem.toString()
        val color = when (colorName) {
            "Kuning" -> Color.rgb(255, 223, 69)
            "Biru" -> Color.rgb(102, 232, 255)
            "Pink" -> Color.rgb(255, 117, 169)
            else -> Color.WHITE
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = maxOf(5f, width / 180f)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val style = findViewById<Spinner>(R.id.styleSpinner).selectedItem.toString()
        val p = Path()
        when (style) {
            "Panah" -> {
                p.moveTo(width * .12f, height * .68f); p.lineTo(width * .78f, height * .25f)
                p.moveTo(width * .78f, height * .25f); p.lineTo(width * .65f, height * .27f)
                p.moveTo(width * .78f, height * .25f); p.lineTo(width * .74f, height * .39f)
            }
            "Lingkaran" -> {
                canvas.drawCircle(width * .68f, height * .43f, width * .14f, paint)
                canvas.drawCircle(width * .25f, height * .70f, width * .07f, paint)
            }
            "Bintang" -> {
                drawStar(canvas, paint, width * .25f, height * .27f, width * .09f)
                drawStar(canvas, paint, width * .75f, height * .65f, width * .10f)
            }
            "Minimal" -> {
                p.moveTo(width * .1f, height * .3f)
                p.quadTo(width * .4f, height * .18f, width * .72f, height * .29f)
                p.moveTo(width * .35f, height * .72f)
                p.quadTo(width * .62f, height * .62f, width * .9f, height * .73f)
            }
            "Scribble" -> {
                p.moveTo(width * .08f, height * .28f)
                for (i in 1..9) p.lineTo(width * (.08f + i * .095f), height * (.28f + if (i % 2 == 0) -.045f else .045f))
            }
            else -> {
                p.moveTo(width * .08f, height * .28f)
                for (i in 1..9) p.lineTo(width * (.08f + i * .095f), height * (.28f + if (i % 2 == 0) -.045f else .045f))
                canvas.drawCircle(width * .72f, height * .46f, width * .10f, paint)
                drawStar(canvas, paint, width * .25f, height * .68f, width * .07f)
            }
        }
        canvas.drawPath(p, paint)
        return bitmap
    }

    private fun drawStar(canvas: Canvas, paint: Paint, cx: Float, cy: Float, radius: Float) {
        val path = Path()
        for (i in 0 until 10) {
            val angle = Math.PI * i / 5.0 - Math.PI / 2
            val r = if (i % 2 == 0) radius else radius * .42f
            val x = cx + (kotlin.math.cos(angle) * r).toFloat()
            val y = cy + (kotlin.math.sin(angle) * r).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, paint)
    }

    private fun startExport() {
        val input = selectedUri ?: return
        if (isExporting) return
        isExporting = true
        exportButton.isEnabled = false
        progress.visibility = ProgressBar.VISIBLE
        progress.isIndeterminate = true
        statusText.text = "Menyiapkan encoder video…"

        val resolution = findViewById<Spinner>(R.id.resolutionSpinner).selectedItemPosition
        val overlayBitmap = makeDoodleBitmap(if (resolution == 0) 720 else 1080, if (resolution == 0) 1280 else 1920)
        val overlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap)
        val overlayEffect = OverlayEffect(listOf(overlay))
        val editedItem = EditedMediaItem.Builder(MediaItem.fromUri(input))
            .setEffects(Effects(emptyList(), listOf(overlayEffect)))
            .build()

        val outputFile = File(cacheDir, "doodle_export_${System.currentTimeMillis()}.mp4")
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                runOnUiThread {
                    try {
                        val saved = saveToGallery(outputFile)
                        statusText.text = if (saved != null) "Selesai! Video MP4 tersimpan di Movies/DoodleRepost." else "Export selesai, tetapi gagal menyimpan ke galeri."
                        Toast.makeText(this@MainActivity, if (saved != null) "Video berhasil disimpan" else "Gagal menyimpan video", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        statusText.text = "Export selesai, gagal menyalin ke galeri: ${e.message}"
                    }
                    finishExport()
                    overlayBitmap.recycle()
                    outputFile.delete()
                }
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                runOnUiThread {
                    statusText.text = "Export gagal: ${exportException.errorCodeName}. Coba video MP4 H.264 dan resolusi 720p."
                    finishExport()
                    overlayBitmap.recycle()
                    outputFile.delete()
                }
            }
        }

        transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(listener)
            .build()

        try {
            transformer?.start(editedItem, outputFile.absolutePath)
        } catch (e: Exception) {
            statusText.text = "Tidak bisa memulai export: ${e.message}"
            finishExport()
            overlayBitmap.recycle()
            outputFile.delete()
        }
    }

    private fun finishExport() {
        isExporting = false
        exportButton.isEnabled = selectedUri != null
        progress.visibility = ProgressBar.GONE
        transformer = null
    }

    private fun saveToGallery(file: File): Uri? {
        if (!file.exists() || file.length() == 0L) return null
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "DoodleRepost_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DoodleRepost")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { it.copyTo(out) } }
        return uri
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
